﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core_Master_Detail.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        [Required, StringLength(100), Display(Name = "Customer Name")]
        public string CustomerName { get; set; } = default!;
        [Required, Display(Name = "Date Of Birth"), Column(TypeName = "date"), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; } = default!;
        public string Phone { get; set; } = default!;
        public string? Image { get; set; }
        public bool NewCustomer { get; set; }
        public virtual ICollection<CustomerProduct> CustomerProducts { get; set; } = new List<CustomerProduct>();
        public virtual ICollection<Price> Prices { get; set; } = new List<Price>();
    }
    public class Product
    {
        public int ProductId { get; set; }
        [Required, StringLength(100), Display(Name = "Product Name")]
        public string ProductName { get; set; } = default!;
        public virtual ICollection<CustomerProduct> CustomerProducts { get; set; } = new List<CustomerProduct>();
        public virtual ICollection<Price> Prices { get; set; } = new List<Price>();

    }
    public class CustomerProduct
    {
        public int CustomerProductId { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }
        public virtual Customer? Customer { get; set; }
        public virtual Product? Product { get; set; }
    }
    public class CustomerDbContext : DbContext
    {
        public CustomerDbContext(DbContextOptions<CustomerDbContext> options) : base(options) { }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<CustomerProduct> CustomersProducts { get; set; }
        public DbSet<Price> Prices { get; set; }

    }
    public class Price
    {
        public int Id { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }
        public int Prices { get; set; }

        //nev
        public virtual Customer? Customer { get; set; }
        public virtual Product? Product { get; set; }
    }
}
