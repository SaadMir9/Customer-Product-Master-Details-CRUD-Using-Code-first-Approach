﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core_Master_Detail.Models.ViewModels
{
    public class CustomerVM
    {
        public int CustomerId { get; set; }
        [Required, StringLength(100), Display(Name = "Customer Name")]
        public string CustomerName { get; set; } = default!;
        [Required, Display(Name = "Date Of Birth"), Column(TypeName = "date"), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; } = default!;
        public string Phone { get; set; } = default!;
        public string? Image { get; set; }
        [Display(Name = "Image")]
        public IFormFile? ImagePath { get; set; }
        public bool NewCustomer { get; set; }
        public List<int> ProductList { get; set; } = new List<int>();
    }
}
