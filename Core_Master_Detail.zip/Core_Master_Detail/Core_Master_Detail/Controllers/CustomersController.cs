﻿using Core_Master_Detail.Models.ViewModels;
using Core_Master_Detail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Core_Master_Detail.Controllers
{
    public class CustomersController : Controller
    {
        private IWebHostEnvironment _he;
        private CustomerDbContext _context;
        public CustomersController(IWebHostEnvironment _he, CustomerDbContext _context)
        {
            this._context = _context;
            this._he = _he;
        }
        public async Task<IActionResult> Index()
        {

            return View(await _context.Customers.Include(x => x.CustomerProducts).ThenInclude(y => y.Product).ToListAsync());
        }
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult AddNewProduct(int? id)
        {
            ViewBag.Product = new SelectList(_context.Products, "ProductId", "ProductName", id.ToString() ?? "");
            return PartialView("_AddNewProduct");
        }
        [HttpPost]
        public async Task<IActionResult> Create(CustomerVM VM, int[] ProductId)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    CustomerName = VM.CustomerName,
                    DateOfBirth = VM.DateOfBirth,
                    Phone = VM.Phone,
                    NewCustomer = VM.NewCustomer
                };
                //image
                var file = VM.ImagePath;
                string webroot = _he.WebRootPath;
                string folder = "Images";
                string imgFileName = DateTime.Now.Ticks.ToString() + "_" + Path.GetFileName(VM.ImagePath.FileName);
                string fileToSave = Path.Combine(webroot, folder, imgFileName);

                if (file != null)
                {
                    using (var stream = new FileStream(fileToSave, FileMode.Create))
                    {
                        VM.ImagePath.CopyTo(stream);
                        customer.Image = "/" + folder + "/" + imgFileName;
                    }
                }
                foreach (var item in ProductId)
                {
                    CustomerProduct customerProduct = new CustomerProduct()
                    {
                        Customer = customer,
                        CustomerId = customer.CustomerId,
                        ProductId = item
                    };
                    _context.CustomersProducts.Add(customerProduct);
                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));

            }
            return View();
        }
        public async Task<IActionResult> Edit(int? id)
        {
            var customer = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerId == id);

            CustomerVM VM = new CustomerVM()
            {
                CustomerId = customer.CustomerId,
                CustomerName = customer.CustomerName,
                DateOfBirth = customer.DateOfBirth,
                Phone = customer.Phone,
                Image = customer.Image,
                NewCustomer = customer.NewCustomer
            };
            var existReport = _context.CustomersProducts.Where(x => x.CustomerId == id).ToList();
            foreach (var item in existReport)
            {
                VM.ProductList.Add(item.ProductId);
            }
            return View(VM);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CustomerVM VM, int[] ProductId)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    CustomerId = VM.CustomerId,
                    CustomerName = VM.CustomerName,
                    DateOfBirth = VM.DateOfBirth,
                    Phone = VM.Phone,
                    NewCustomer = VM.NewCustomer,
                    Image = VM.Image
                };
                var file = VM.ImagePath;
                string existImg = VM.Image;

                if (file != null)
                {
                    string webroot = _he.WebRootPath;
                    string folder = "Images";
                    string imgFileName = DateTime.Now.Ticks.ToString() + "_" + Path.GetFileName(VM.ImagePath.FileName);
                    string fileToSave = Path.Combine(webroot, folder, imgFileName);
                    using (var stream = new FileStream(fileToSave, FileMode.Create))
                    {
                        VM.ImagePath.CopyTo(stream);
                        customer.Image = "/" + folder + "/" + imgFileName;
                    }

                }
                else
                {
                    customer.Image = existImg;
                }

                var existReport = _context.CustomersProducts.Where(x => x.CustomerId == customer.CustomerId).ToList();
                //Remove
                foreach (var item in existReport)
                {
                    _context.CustomersProducts.Remove(item);
                }
                //Add
                foreach (var item in ProductId)
                {
                    CustomerProduct customerProduct = new CustomerProduct()
                    {
                        CustomerId = customer.CustomerId,
                        ProductId = item
                    };
                    _context.CustomersProducts.Add(customerProduct);
                }
                _context.Update(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
        public async Task<IActionResult> Delete(int? id)
        {
            var customer = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerId == id);
            var existReport = _context.CustomersProducts.Where(x => x.CustomerId == id).ToList();
            foreach (var item in existReport)
            {
                _context.CustomersProducts.Remove(item);
            }

            _context.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
